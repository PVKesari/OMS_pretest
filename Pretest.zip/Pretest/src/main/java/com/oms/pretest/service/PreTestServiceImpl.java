package com.oms.pretest.service;

import com.oms.pretest.model.Demand;
import com.oms.pretest.model.Order;
import com.oms.pretest.model.Shipment;
import com.oms.pretest.model.Supply;
import com.oms.pretest.utility.OrderShipmentResponse;
import com.oms.pretest.utility.SupplyDemandResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.concurrent.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class PreTestServiceImpl implements PreTestService{


    @Override
    public ResponseEntity<Object> getOrderDetails(String orderId) {
        {
            log.info("Inside getOrderDetails");
            ExecutorService executor = Executors.newFixedThreadPool(5);
            List<Callable<Object>> callableList = new ArrayList<>();

            List<Future<Object>> results = null;
            OrderShipmentResponse orderShipmentResponse = new OrderShipmentResponse();
            try {
                callableList.add(() -> getOrdDetails(orderId));
                callableList.add(() -> getShipments(orderId));
                results = executor.invokeAll(callableList);

                List<Order> order = (List<Order>) results.get(0).get();
                List<Shipment> shipment = (List<Shipment>) results.get(1).get();

                log.info("OrderList",order);
                log.info("ShipmentList",shipment);

                orderShipmentResponse.setOrder(order);
                orderShipmentResponse.setShipment(shipment);


            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            } catch (ExecutionException e) {
                throw new RuntimeException(e);
            } finally {
                executor.shutdown();
            }

            return ResponseEntity.ok().body(orderShipmentResponse);
        }

    }

    private List<Order> getOrdDetails(String orderId) {

        List<Order> orderList = Arrays.asList(new Order("Order1", "Prod1", 2.0));

        List<Order> orders = orderList.stream().filter(o -> o.getOrderId().equalsIgnoreCase(orderId)).collect(Collectors.toList());

        return orders;
    }

    private List<Shipment> getShipments(String orderId) {

        //("Order1", "Ship1", "Prod1" new Date (2021 - 02 - 19), 2.0

        List<Shipment> shipmentList = Arrays.asList(new Shipment("Order1", "Ship1", "Prod1", new Date(2021-02-19), 2.0));

        List<Shipment> shipments = shipmentList.stream().filter(o -> o.getOrderId().equalsIgnoreCase(orderId)).collect(Collectors.toList());

        return shipments;
    }

    @Override
    public ResponseEntity<Object> getAvailability(String productId) {

//        Supply("Product1",10),
//                Supply ("Product2",5),
//                Demand("Product1",2),
//                Demand("Product2",5),


        List<Supply> supplies = Arrays.asList(new Supply("Product1", Double.valueOf(10)),
                new Supply("Product2", Double.valueOf(5)));

        List<Demand> demands = Arrays.asList(new Demand("Product1", Double.valueOf(2)),
                new Demand("Product2", Double.valueOf(5)));


        List<Supply> supplyList = supplies.stream().filter(o -> o.getProductId().equalsIgnoreCase(productId)).collect(Collectors.toList());
        List<Demand> demandList = demands.stream().filter(o -> o.getProductId().equalsIgnoreCase(productId)).collect(Collectors.toList());

        Double availablity = supplyList.get(0).getQuantity() - demandList.get(0).getQuantity();
        if (availablity != 0) {
            SupplyDemandResponse supplyDemandResponse = new SupplyDemandResponse(productId, availablity);
            return ResponseEntity.ok(supplyDemandResponse);
        } else {
            return  new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
    }
}
