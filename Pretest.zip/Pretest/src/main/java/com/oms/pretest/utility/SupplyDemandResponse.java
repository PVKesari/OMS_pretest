package com.oms.pretest.utility;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class SupplyDemandResponse {

    String productId;
    Double availability;
}
