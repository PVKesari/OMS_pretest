package com.oms.pretest.controller;

import com.oms.pretest.service.PreTestServiceImpl;
import com.oms.pretest.utility.OrderShipmentRequest;
import com.oms.pretest.utility.OrderShipmentResponse;
import com.oms.pretest.utility.SupplyDemandRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class PreTestController {

    @Autowired
    PreTestServiceImpl preTestService;

    @PostMapping("/getOrderDetails")
    public ResponseEntity<Object> getOrderDetails(@RequestBody OrderShipmentRequest reqBody){


        return preTestService.getOrderDetails(reqBody.getOrderId());

    }



    @PostMapping("/getAvailability")
    public ResponseEntity<Object> getAvailability(@RequestBody SupplyDemandRequest supplyDemandReq){


        return preTestService.getAvailability(supplyDemandReq.getProductId());

    }

    @PostMapping("/get")
    public String get(){
        return "Test";
    }
}

