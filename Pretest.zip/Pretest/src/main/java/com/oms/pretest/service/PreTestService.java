package com.oms.pretest.service;

import com.oms.pretest.utility.OrderShipmentResponse;
import org.springframework.http.ResponseEntity;

public interface PreTestService {

    public ResponseEntity<Object> getOrderDetails(String orderId);

    public ResponseEntity<Object> getAvailability(String productId);
}
