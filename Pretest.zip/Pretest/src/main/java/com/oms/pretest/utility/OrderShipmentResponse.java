package com.oms.pretest.utility;

import com.oms.pretest.model.Order;
import com.oms.pretest.model.Shipment;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderShipmentResponse {
    List<Order> order;
    List<Shipment>  shipment;
}
