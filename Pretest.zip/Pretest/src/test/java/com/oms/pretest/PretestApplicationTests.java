package com.oms.pretest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PretestApplicationTests {

	@Test
	void contextLoads() {
	}

}
